import debug from "debug";
import * as fsPromises from "fs/promises";
import type { FileSystemAdapter } from "obsidian";
import { normalizePath, Notice, Platform } from "obsidian";
import * as path from "path";
import { resolve, sep } from "path";
import type * as simple from "simple-git";
import simpleGit, { GitError, CleanOptions } from "simple-git";
import {
    ASK_PASS_INPUT_FILE,
    ASK_PASS_SCRIPT,
    ASK_PASS_SCRIPT_FILE,
    DEFAULT_WIN_GIT_PATH,
    GIT_LINE_AUTHORING_MOVEMENT_DETECTION_MINIMAL_LENGTH,
} from "src/constants";
import type { LineAuthorFollowMovement } from "src/editor/lineAuthor/model";
import { GeneralModal } from "src/ui/modals/generalModal";
import type ObsidianGit from "../main";
import type {
    Blame,
    BlameCommit,
    BranchInfo,
    DiffFile,
    FileStatusResult,
    GitProgress,
    LogEntry,
    Status,
} from "../types";
import { GitOperation, NoNetworkError } from "../types";
import { impossibleBranch, spawnAsync, splitRemoteBranch } from "../utils";
import { GitManager } from "./gitManager";

export class SimpleGit extends GitManager {
    git!: simple.SimpleGit;
    absoluteRepoPath!: string;
    watchAbortController: AbortController | undefined;
    useDefaultWindowsGitPath: boolean = false;
    constructor(plugin: ObsidianGit) {
        super(plugin);
    }

    async setGitInstance(ignoreError = false): Promise<void> {
        if (await this.isGitInstalled()) {
            const adapter = this.app.vault.adapter as FileSystemAdapter;
            const vaultBasePath = adapter.getBasePath();
            let basePath = vaultBasePath;
            // Because the basePath setting is a relative path, a leading `/` must
            // be appended before concatenating with the path.
            if (this.plugin.settings.basePath) {
                const exists = await adapter.exists(
                    normalizePath(this.plugin.settings.basePath)
                );
                if (exists) {
                    basePath = path.join(
                        vaultBasePath,
                        this.plugin.settings.basePath
                    );
                } else if (!ignoreError) {
                    new Notice("ObsidianGit: Base path does not exist");
                }
            }
            this.absoluteRepoPath = basePath;

            this.git = simpleGit({
                baseDir: basePath,
                binary:
                    this.plugin.localStorage.getGitPath() ||
                    (this.useDefaultWindowsGitPath
                        ? DEFAULT_WIN_GIT_PATH
                        : undefined),
                config: ["core.quotepath=off"],
                progress: (progress) => {
                    this.plugin.statusBar?.displayProgress(
                        this.toGitProgress(progress)
                    );
                },
                unsafe: {
                    allowUnsafeCustomBinary: true,
                    allowUnsafeEditor: true,
                    allowUnsafeAskPass: true,
                    allowUnsafeConfigEnvCount: true,
                    allowUnsafeConfigPaths: true,
                    allowUnsafeCredentialHelper: true,
                    allowUnsafeGitProxy: true,
                    allowUnsafeGpgProgram: true,
                    allowUnsafeHooksPath: true,
                    allowUnsafeMergeDriver: true,
                    allowUnsafeSshCommand: true,
                    allowUnsafePager: true,
                },
            });
            const pathPaths = this.plugin.localStorage.getPATHPaths();
            const envVars = this.plugin.localStorage.getEnvVars();
            const gitDir = this.plugin.settings.gitDir;
            const envs = { ...process.env };
            if (pathPaths.length > 0) {
                const joinedPath =
                    pathPaths.join(path.delimiter) +
                    path.delimiter +
                    envs["PATH"];
                envs["PATH"] = joinedPath;
            }
            if (gitDir) {
                envs["GIT_DIR"] = gitDir;
                envs["GIT_WORK_TREE"] = basePath;
            }
            for (const envVar of envVars) {
                const [key, value] = envVar.split("=");
                if (key === undefined) continue;
                envs[key] = value;
            }

            const SIMPLE_GIT_NAMESPACE = "simple-git";
            const NAMESPACE_SEPARATOR = ",";
            const currentDebug = (localStorage.debug ?? "") as string;
            const namespaces = currentDebug.split(NAMESPACE_SEPARATOR);

            if (
                !namespaces.includes(SIMPLE_GIT_NAMESPACE) &&
                !namespaces.includes(`-${SIMPLE_GIT_NAMESPACE}`)
            ) {
                namespaces.push(SIMPLE_GIT_NAMESPACE);
                debug.enable(namespaces.join(NAMESPACE_SEPARATOR));
            }

            if (await this.git.env(envs).checkIsRepo()) {
                // Resolve the relative root reported by git into an absolute path
                // in case git resides in a different filesystem (eg, WSL)
                const relativeRoot = await this.git.revparse("--show-cdup");
                const absoluteRoot = resolve(basePath + sep + relativeRoot);

                this.absoluteRepoPath = absoluteRoot;
                await this.git.cwd(absoluteRoot);
            }

            const absolutePluginConfigPath = path.join(
                vaultBasePath,
                this.app.vault.configDir,
                "plugins",
                "obsidian-git"
            );
            const askPassPath = path.join(
                absolutePluginConfigPath,
                ASK_PASS_SCRIPT_FILE
            );

            if (envs["SSH_ASKPASS"] == undefined) {
                envs["SSH_ASKPASS"] = askPassPath;
            }

            // OpenSSH requires DISPLAY variable to be set for SSH_ASKPASS to
            // detect a graphical environment. This is not the case for e.g.
            // Windows. Setting SSH_ASKPASS_REQUIRE to "force" makes it use
            // SSH_ASKPASS even without DISPLAY, which allows the askpass script
            // to work on Windows as well.
            envs["SSH_ASKPASS_REQUIRE"] = "force";
            envs["OBSIDIAN_GIT_CREDENTIALS_INPUT"] = path.join(
                absolutePluginConfigPath,
                ASK_PASS_INPUT_FILE
            );
            if (envs["SSH_ASKPASS"] == askPassPath) {
                this.askpass().catch((e) => this.plugin.displayError(e));
            }

            envs["OBSIDIAN_GIT"] = "1";

            this.git = this.git.env(envs);
        }
    }

    private toGitProgress(
        progress: simple.SimpleGitProgressEvent
    ): GitProgress {
        return {
            action: this.getProgressAction(progress.method),
            stage: progress.stage,
            progress: progress.progress,
            processed: progress.processed,
            total: progress.total,
        };
    }

    private getProgressAction(method: string): string {
        switch (method) {
            case "fetch":
                return "Fetching";
            case "push":
                return "Pushing";
            case "pull":
                return "Pulling";
            case "checkout":
                return "Checking out";
            default:
                return method
                    ? method.charAt(0).toUpperCase() + method.slice(1)
                    : "Working";
        }
    }

    // Constructs a path relative to the vault from a path relative to the git repository
    getRelativeVaultPath(filePath: string): string {
        const adapter = this.app.vault.adapter as FileSystemAdapter;
        const from = adapter.getBasePath();

        const to = path.join(this.absoluteRepoPath, filePath);

        let res = path.relative(from, to);
        if (Platform.isWin) {
            res = res.replace(/\\/g, "/");
        }
        return res;
    }

    // Constructs a path relative to the git repository from a path relative to the vault
    //
    // @param doConversion - If false, the path is returned as is. This is added because that parameter is often passed on to functions where this method is called.
    getRelativeRepoPath(
        filePath: string,
        doConversion: boolean = true
    ): string {
        if (doConversion) {
            const adapter = this.plugin.app.vault.adapter as FileSystemAdapter;
            const vaultPath = adapter.getBasePath();
            const from = this.absoluteRepoPath;
            const to = path.join(vaultPath, filePath);
            let res = path.relative(from, to);
            if (Platform.isWin) {
                res = res.replace(/\\/g, "/");
            }
            return res;
        }
        return filePath;
    }

    private get absPluginConfigPath(): string {
        const adapter = this.app.vault.adapter as FileSystemAdapter;
        const vaultPath = adapter.getBasePath();
        return path.join(
            vaultPath,
            this.app.vault.configDir,
            "plugins",
            "obsidian-git"
        );
    }

    private get relPluginConfigPath(): string {
        return path.join(this.app.vault.configDir, "plugins", "obsidian-git");
    }
    async askpass(): Promise<void> {
        const adapter = this.app.vault.adapter as FileSystemAdapter;
        const relPluginConfigDir =
            this.app.vault.configDir + "/plugins/obsidian-git/";

        await this.addAskPassScriptToExclude();

        await fsPromises.writeFile(
            path.join(this.absPluginConfigPath, ASK_PASS_SCRIPT_FILE),
            ASK_PASS_SCRIPT
        );
        await fsPromises.chmod(
            path.join(this.absPluginConfigPath, ASK_PASS_SCRIPT_FILE),
            0o755
        );
        this.watchAbortController = new AbortController();
        const { signal } = this.watchAbortController;
        try {
            const watcher = fsPromises.watch(this.absPluginConfigPath, {
                signal,
            });

            for await (const event of watcher) {
                if (event.filename != ASK_PASS_INPUT_FILE) continue;
                const triggerFilePath =
                    relPluginConfigDir + ASK_PASS_INPUT_FILE;

                // Wait a bit to ensure the file is fully removed
                await new Promise((res) => window.setTimeout(res, 200));
                if (!(await adapter.exists(triggerFilePath))) continue;

                const data = await adapter.read(triggerFilePath);
                let notice: Notice | undefined;
                // The text is too long for the modal, so a notice is shown instead
                if (data.length > 60) {
                    notice = new Notice(data, 999_999);
                }
                let obscure = true;

                // This does only work for English output.
                // There is no general way detect the type of input asked for.
                // We could enfore english output, but that is not beneficial
                // for the user either.
                if (data.contains("Username for")) {
                    obscure = false;
                }
                const response = await new GeneralModal(this.plugin, {
                    allowEmpty: true,
                    obscure,
                    placeholder:
                        data.length > 60
                            ? "Enter a response to the message."
                            : data,
                }).openAndGetResult();
                notice?.hide();

                // Just in case the trigger file was removed while the modal was open
                if (await adapter.exists(triggerFilePath)) {
                    await adapter.write(
                        `${triggerFilePath}.response`,
                        response ?? ""
                    );
                }
            }
        } catch (error) {
            this.plugin.displayError(error);
            await fsPromises.rm(
                path.join(this.absPluginConfigPath, ASK_PASS_SCRIPT_FILE),
                { force: true }
            );
            await fsPromises.rm(
                path.join(
                    this.absPluginConfigPath,
                    `${ASK_PASS_SCRIPT_FILE}.response`
                ),
                { force: true }
            );
            await new Promise((res) => window.setTimeout(res, 5000));
            this.plugin.log("Retry watch for ask pass");
            await this.askpass();
        }
    }

    /**
     * Adds the askpass script to the exclude file of the git repository.
     *
     * This prevents the script from being tracked by git. This should be no
     * problem as the script does not contain any sensitive data, but may
     * cause issues with file permissions on other devices.
     * See https://github.com/Vinzent03/obsidian-git/issues/903
     */
    async addAskPassScriptToExclude(): Promise<void> {
        try {
            if (!(await this.git.checkIsRepo())) {
                return;
            }
            const absoluteExcludeFilePath = await this.git.revparse([
                "--path-format=absolute",
                "--git-path",
                "info/exclude",
            ]);

            const vaultRelativeAskPassScriptFile = path.join(
                this.app.vault.configDir,
                "plugins",
                "obsidian-git",
                ASK_PASS_SCRIPT_FILE
            );
            const repoRelativeAskPassScriptFile = this.getRelativeRepoPath(
                vaultRelativeAskPassScriptFile,
                true
            );

            const content = await fsPromises.readFile(
                absoluteExcludeFilePath,
                "utf-8"
            );
            const lines = content.split("\n");
            const contains = lines.some((line) =>
                line.contains(repoRelativeAskPassScriptFile)
            );
            if (!contains) {
                await fsPromises.appendFile(
                    absoluteExcludeFilePath,
                    repoRelativeAskPassScriptFile + "\n"
                );
            }
        } catch (error) {
            // Catch any errors, because this is not critical
            console.error(
                "Error while adding askpass script to exclude file:",
                error
            );
        }
    }

    unload(): void {
        this.watchAbortController?.abort();
    }

    async status(opts?: { path?: string }): Promise<Status> {
        const dir = opts?.path;
        const status = await this.git.status(
            dir != undefined ? ["--", dir] : []
        );

        const allFilesFormatted = status.files.map<FileStatusResult>((e) => {
            const res = this.formatPath(e);
            return {
                path: res.path,
                from: res.from,
                index: e.index === "?" ? "U" : e.index,
                workingDir: e.working_dir === "?" ? "U" : e.working_dir,
                vaultPath: this.getRelativeVaultPath(res.path),
            };
        });
        return {
            all: allFilesFormatted,
            changed: allFilesFormatted.filter((e) => e.workingDir !== " "),
            staged: allFilesFormatted.filter(
                (e) => e.index !== " " && e.index != "U"
            ),
            conflicted: status.conflicted.map(
                (path) => this.formatPath({ path }).path
            ),
        };
    }

    async submoduleAwareHeadRevisonInContainingDirectory(
        filepath: string
    ): Promise<string> {
        const repoPath = this.getRelativeRepoPath(filepath);

        const containingDirectory = path.dirname(repoPath);
        const args = ["-C", containingDirectory, "rev-parse", "HEAD"];

        const result = this.git.raw(args);
        result.catch((err) =>
            console.warn("obsidian-git: rev-parse error:", err)
        );
        return (await result).trim();
    }

    async getSubmodulePaths(): Promise<string[]> {
        return new Promise<string[]>((resolve) => {
            this.git.outputHandler((_cmd, stdout, _stderr, args) => {
                // Do not run this handler on other commands
                if (!(args.contains("submodule") && args.contains("foreach"))) {
                    return;
                }

                let body = "";
                // `submodule foreach` prints paths relative to git's cwd, which
                // is the repo root (see setGitInstance), not the vault folder.
                // The vault may live in a subfolder of the repo, in which case
                // prefixing the vault path yields a non-existent directory.
                const root = this.absoluteRepoPath;
                stdout.on("data", (chunk: Buffer) => {
                    body += chunk.toString("utf8");
                });
                stdout.on("end", () => {
                    const submods = body.split("\n");

                    // Remove words like `Entering` in front of each line and filter empty lines
                    const strippedSubmods: string[] = submods
                        .map((i) => {
                            const submod = i.match(/'([^']*)'/);
                            if (submod != undefined) {
                                return root + "/" + submod[1]! + sep;
                            }
                            return undefined;
                        })
                        .filter((i): i is string => !!i);

                    strippedSubmods.reverse();
                    resolve(strippedSubmods);
                });
            });

            this.git.subModule(["foreach", "--recursive", ""]).then(
                () => {
                    this.git.outputHandler(() => {});
                },
                (e) => this.plugin.displayError(e)
            );
        });
    }

    //Remove wrong `"` like "My file.md"
    formatPath(path: { from?: string; path: string }): {
        path: string;
        from?: string;
    } {
        function format(path?: string): string | undefined {
            if (path == undefined) return undefined;

            if (path.startsWith('"') && path.endsWith('"')) {
                return path.substring(1, path.length - 1);
            } else {
                return path;
            }
        }
        if (path.from != undefined) {
            return {
                from: format(path.from),
                path: format(path.path)!,
            };
        } else {
            return {
                path: format(path.path)!,
            };
        }
    }

    async blame(
        path: string,
        trackMovement: LineAuthorFollowMovement,
        ignoreWhitespace: boolean
    ): Promise<Blame | "untracked"> {
        path = this.getRelativeRepoPath(path);

        if (!(await this.isTracked(path))) return "untracked";

        const inSubmodule = await this.getSubmoduleOfFile(path);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativePath = inSubmodule ? inSubmodule.relativeFilepath : path;

        args.push("blame", "--porcelain");

        if (ignoreWhitespace) args.push("-w");

        const trackCArg = `-C${GIT_LINE_AUTHORING_MOVEMENT_DETECTION_MINIMAL_LENGTH}`;
        switch (trackMovement) {
            case "inactive":
                break;
            case "same-commit":
                args.push("-C", trackCArg);
                break;
            case "all-commits":
                args.push("-C", "-C", trackCArg);
                break;
            default:
                impossibleBranch(trackMovement);
        }

        args.push("--", relativePath);

        const rawBlame = await this.git.raw(args);
        return parseBlame(rawBlame);
    }

    async isTracked(path: string): Promise<boolean> {
        const inSubmodule = await this.getSubmoduleOfFile(path);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativePath = inSubmodule ? inSubmodule.relativeFilepath : path;

        args.push("ls-files", "--", relativePath);
        return this.git.raw(args).then((x) => x.trim() !== "");
    }

    async commitAll({ message }: { message: string }): Promise<number> {
        return this.withGitOperation(GitOperation.commit, async () => {
            if (this.plugin.settings.updateSubmodules) {
                const submodulePaths = await this.getSubmodulePaths();
                for (const item of submodulePaths) {
                    await this.git.cwd({ path: item, root: false }).add("-A");
                    await this.git
                        .cwd({ path: item, root: false })
                        .commit(await this.formatCommitMessage(message));
                }
            }
            await this.git.add("-A");

            const res = await this.git.commit(
                await this.formatCommitMessage(message)
            );
            this.app.workspace.trigger("obsidian-git:head-change");
            return res.summary.changes;
        });
    }

    async commit({
        message,
        amend,
    }: {
        message: string;
        amend?: boolean;
    }): Promise<number> {
        return this.withGitOperation(GitOperation.commit, async () => {
            const res = (
                await this.git.commit(
                    await this.formatCommitMessage(message),
                    amend ? ["--amend"] : []
                )
            ).summary.changes;
            this.app.workspace.trigger("obsidian-git:head-change");
            return res;
        });
    }

    async stage(path: string, relativeToVault: boolean): Promise<void> {
        path = this.getRelativeRepoPath(path, relativeToVault);
        await this.git.add(["--", path]);
    }

    async stageAll({ dir }: { dir?: string }): Promise<void> {
        await this.git.add(dir ?? "-A");
    }

    async unstageAll({ dir }: { dir?: string }): Promise<void> {
        await this.git.reset(dir != undefined ? ["--", dir] : []);
    }

    async unstage(path: string, relativeToVault: boolean): Promise<void> {
        path = this.getRelativeRepoPath(path, relativeToVault);
        await this.git.reset(["--", path]);
    }

    async discard(filepath: string): Promise<void> {
        if (await this.isTracked(filepath)) {
            await this.git.checkout(["--progress", "--", filepath]);
        }
    }

    async applyPatch(patch: string): Promise<void> {
        const patchPath = path.join(this.relPluginConfigPath, "patch");
        await this.app.vault.adapter.write(patchPath, patch);
        await this.git.applyPatch(patchPath, {
            "--cached": null,
            "--unidiff-zero": null,
            "--whitespace": "nowarn",
        });
        await this.app.vault.adapter.remove(patchPath);
    }

    async getUntrackedPaths(opts: { path?: string }): Promise<string[]> {
        const dir = opts?.path;
        const args = [];
        if (dir != undefined) {
            args.push("--", dir);
        }
        const untrackedFiles = await this.git.clean(
            CleanOptions.RECURSIVE + CleanOptions.DRY_RUN,
            args
        );

        return untrackedFiles.paths;
    }

    async hashObject(filepath: string): Promise<string> {
        // Need to use raw command here to ensure filenames are literally used.
        // Perhaps we could file a PR? https://github.com/steveukx/git-js/blob/main/simple-git/src/lib/tasks/hash-object.ts
        filepath = this.getRelativeRepoPath(filepath);
        const inSubmodule = await this.getSubmoduleOfFile(filepath);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativeFilepath = inSubmodule
            ? inSubmodule.relativeFilepath
            : filepath;

        args.push("hash-object", "--", relativeFilepath);

        const revision = this.git.raw(args);
        return revision;
    }

    async discardAll({ dir }: { dir?: string }): Promise<void> {
        return this.discard(dir ?? ".");
    }

    async pull(): Promise<FileStatusResult[] | undefined> {
        return this.withGitOperation(GitOperation.pull, async () => {
            try {
                if (this.plugin.settings.updateSubmodules)
                    await this.git.subModule([
                        "update",
                        "--remote",
                        "--merge",
                        "--recursive",
                    ]);

                const branchInfo = await this.branchInfo();
                if (!branchInfo.current) {
                    this.plugin.displayError(
                        "No current branch found. Cannot pull."
                    );
                    return undefined;
                }
                const localCommit = await this.git.revparse([
                    branchInfo.current,
                ]);

                if (
                    !branchInfo.tracking &&
                    this.plugin.settings.updateSubmodules
                ) {
                    this.plugin.log(
                        "No tracking branch found. Ignoring pull of main repo and updating submodules only."
                    );
                    return;
                }

                await this.git.fetch();
                const upstreamCommit = await this.git.revparse([
                    branchInfo.tracking!,
                ]);

                if (localCommit !== upstreamCommit) {
                    if (
                        this.plugin.settings.syncMethod === "merge" ||
                        this.plugin.settings.syncMethod === "rebase"
                    ) {
                        try {
                            const args = [branchInfo.tracking!];

                            if (this.plugin.settings.mergeStrategy !== "none") {
                                args.push(
                                    `--strategy-option=${this.plugin.settings.mergeStrategy}`
                                );
                            }

                            switch (this.plugin.settings.syncMethod) {
                                case "merge":
                                    await this.git.merge(args);
                                    break;
                                case "rebase":
                                    await this.git.rebase(args);
                            }
                        } catch (err) {
                            this.plugin.displayError(
                                `Pull failed (${this.plugin.settings.syncMethod}): ${errorToString(err)}`
                            );
                            return;
                        }
                    } else if (this.plugin.settings.syncMethod === "reset") {
                        try {
                            await this.git.raw([
                                "update-ref",
                                `refs/heads/${branchInfo.current}`,
                                upstreamCommit,
                            ]);
                            await this.git.reset([]);
                        } catch (err) {
                            this.plugin.displayError(
                                `Sync failed (${this.plugin.settings.syncMethod}): ${errorToString(err)}`
                            );
                        }
                    }
                    this.app.workspace.trigger("obsidian-git:head-change");

                    const afterMergeCommit = await this.git.revparse([
                        branchInfo.current,
                    ]);

                    const filesChanged = await this.git.diff([
                        `${localCommit}..${afterMergeCommit}`,
                        "--name-only",
                    ]);

                    return filesChanged
                        .split(/\r\n|\r|\n/)
                        .filter((value) => value.length > 0)
                        .map((e) => {
                            return <FileStatusResult>{
                                path: e,
                                workingDir: "P",
                                vaultPath: this.getRelativeVaultPath(e),
                            };
                        });
                } else {
                    return [];
                }
            } catch (e) {
                this.convertErrors(e);
            }
        });
    }

    async push(): Promise<number | undefined | null> {
        return this.withGitOperation(GitOperation.push, async () => {
            try {
                if (this.plugin.settings.updateSubmodules) {
                    const res = await this.git.subModule([
                        "foreach",
                        "--recursive",
                        `tracking=$(git for-each-ref --format='%(upstream:short)' "$(git symbolic-ref -q HEAD)"); echo $tracking; if [ ! -z "$(git diff --shortstat $tracking)" ]; then git push; fi`,
                    ]);
                    console.log(res);
                }
                const status = await this.git.status();
                const currentBranch = status.current;

                if (!currentBranch) {
                    this.plugin.displayError(
                        "No current branch found. Cannot push."
                    );
                    return undefined;
                }

                const pushTarget = await this.getPushTarget(currentBranch);

                if (!pushTarget && this.plugin.settings.updateSubmodules) {
                    this.plugin.log(
                        "No push target found. Ignoring push of main repo and updating submodules only."
                    );
                    return undefined;
                }
                let remoteChangedFiles: number | null = null;
                if (pushTarget?.exists) {
                    remoteChangedFiles = (
                        await this.git.diffSummary([
                            currentBranch,
                            pushTarget.ref,
                            "--",
                        ])
                    ).changed;
                }

                await this.git.push();

                return remoteChangedFiles;
            } catch (e) {
                this.convertErrors(e);
            }
        });
    }

    /**
     * Returns the remote-tracking ref that represents where an argument-less
     * `git push` sends the current branch. Unlike the upstream ref, this takes
     * push.default, branch.<name>.pushRemote and remote.pushDefault into
     * account. The ref can be configured even when the remote branch has not
     * been created yet.
     */
    private async getPushTarget(
        currentBranch: string
    ): Promise<{ ref: string; exists: boolean } | undefined> {
        const ref = (
            await this.git.raw([
                "for-each-ref",
                "--format=%(push)",
                `refs/heads/${currentBranch}`,
            ])
        ).trim();
        if (!ref) {
            return undefined;
        }

        const existingRef = (
            await this.git.raw(["for-each-ref", "--format=%(refname)", ref])
        ).trim();
        return { ref, exists: existingRef === ref };
    }

    /**
     * Squashes all local commits that have not been pushed yet into a single
     * commit. Only unpushed history is rewritten (HEAD is soft-reset onto the
     * push target), so this never requires a force-push and is safe across
     * multiple devices. The squash commit reuses the message of the most recent
     * unpushed commit, so a custom, modal or script-derived commit message is
     * preserved instead of being overwritten by the auto-commit template.
     * No-op if there is no push target, the push target does not exist yet,
     * there are fewer than two unpushed commits, a merge commit is present in
     * the unpushed range, or there are staged but uncommitted changes.
     */
    async squashAllUnpushedCommits(): Promise<void> {
        const status = await this.git.status();
        if (!status.current) {
            return;
        }
        // There is no safe remote base to reset onto before the push target has
        // been created, or when Git cannot determine an argument-less push
        // destination. Let the normal push publish the existing history.
        const pushTarget = await this.getPushTarget(status.current);
        if (!pushTarget?.exists) {
            return;
        }
        // A soft reset keeps the index, so any staged but uncommitted changes
        // would be folded into the squash commit, silently committing work the
        // user did not intend to. Abort the squash and let the push proceed
        // with the existing history untouched.
        const staged = (
            await this.git.raw(["diff", "--cached", "--name-only"])
        ).trim();
        if (staged.length > 0) {
            return;
        }
        const range = `${pushTarget.ref}..HEAD`;
        const unpushed = parseInt(
            (await this.git.raw(["rev-list", "--count", range])).trim(),
            10
        );
        if (unpushed < 2) {
            return;
        }
        // Flattening a merge commit would lose its structure, so skip those.
        const merges = parseInt(
            (
                await this.git.raw(["rev-list", "--merges", "--count", range])
            ).trim(),
            10
        );
        if (merges > 0) {
            return;
        }
        // Capture the current tip before rewriting so the squash commit can
        // reuse its message (commit -C) rather than the auto-commit template.
        const oldHead = (await this.git.raw(["rev-parse", "HEAD"])).trim();
        await this.withGitOperation(GitOperation.commit, async () => {
            // Soft reset keeps the index and working tree, so all unpushed
            // changes stay staged and are re-committed as a single commit.
            await this.git.reset(["--soft", pushTarget.ref]);
            await this.git.raw(["commit", "-C", oldHead]);
            this.app.workspace.trigger("obsidian-git:head-change");
        });
    }

    async getUnpushedCommits(): Promise<number> {
        const status = await this.git.status();
        const currentBranch = status.current;

        if (currentBranch == null) {
            return 0;
        }

        const pushTarget = await this.getPushTarget(currentBranch);
        if (!pushTarget) {
            return 0;
        }
        if (!pushTarget.exists) {
            this.plugin.log(
                `Push target ${pushTarget.ref} does not exist on the remote yet.`
            );
            return 0;
        }

        const remoteChangedFiles = (
            await this.git.diffSummary([currentBranch, pushTarget.ref, "--"])
        ).changed;

        return remoteChangedFiles;
    }

    async canPush(): Promise<boolean> {
        // allow pushing in submodules even if the root has no changes.
        if (this.plugin.settings.updateSubmodules === true) {
            return true;
        }
        const status = await this.git.status();
        const currentBranch = status.current;
        if (!currentBranch) {
            this.plugin.log("During canPush check, no current branch found.");
            return false;
        }

        const pushTarget = await this.getPushTarget(currentBranch);
        if (!pushTarget) {
            return false;
        }
        if (!pushTarget.exists) {
            return true;
        }

        const [currentCommit, pushedCommit] = await Promise.all([
            this.git.revparse([currentBranch]),
            this.git.revparse([pushTarget.ref]),
        ]);

        return currentCommit !== pushedCommit;
    }

    async checkRequirements(): Promise<
        "valid" | "missing-repo" | "missing-git"
    > {
        if (!(await this.isGitInstalled())) {
            return "missing-git";
        }
        if (!(await this.git.checkIsRepo())) {
            return "missing-repo";
        }
        return "valid";
    }

    async branchInfo(): Promise<BranchInfo> {
        const status = await this.git.status();
        const branches = await this.git.branch(["--no-color"]);

        return {
            current: status.current || undefined,
            tracking: status.tracking || undefined,
            branches: branches.all,
        };
    }

    async getRemoteUrl(remote: string): Promise<string | undefined> {
        try {
            return (await this.git.remote(["get-url", remote])) || undefined;
        } catch (error) {
            // Verify the error is at least not about git is not found or similar. Checks if the remote exists or not
            if (String(error).contains(remote)) {
                return undefined;
            } else {
                throw error;
            }
        }
    }

    // https://github.com/kometenstaub/obsidian-version-history-diff/issues/3
    async log(
        file: string | undefined,
        relativeToVault = true,
        limit?: number,
        ref?: string
    ): Promise<(LogEntry & { fileName?: string })[]> {
        let path: string | undefined;
        if (file) {
            path = this.getRelativeRepoPath(file, relativeToVault);
        }
        const opts: Record<string, unknown> = {
            file: path,
            maxCount: limit,
            // Ensures that the changed files are listed for merge commits as well and the commit is not repeated for each parent.
            // This only lists the changed files for the first parent.
            "--diff-merges": "first-parent",
            "--name-status": null,
        };
        if (ref) {
            opts[ref] = null;
        }
        const res = await this.git.log(opts);

        return res.all.map<LogEntry>((e) => ({
            ...e,
            author: {
                name: e.author_name,
                email: e.author_email,
            },
            refs: e.refs.split(", ").filter((e) => e.length > 0),
            diff: {
                ...e.diff!,
                files:
                    e.diff?.files.map<DiffFile>((f) => {
                        const from = "from" in f ? f.from : undefined;
                        return {
                            ...f,
                            status: "status" in f ? f.status! : "M",
                            path: f.file,
                            hash: e.hash,
                            vaultPath: this.getRelativeVaultPath(f.file),
                            fromPath: from,
                            fromVaultPath:
                                from != undefined
                                    ? this.getRelativeVaultPath(from)
                                    : undefined,
                            binary: f.binary,
                        };
                    }) ?? [],
            },
            fileName: e.diff?.files.first()?.file,
        }));
    }

    async show(
        commitHash: string,
        file: string,
        relativeToVault = true
    ): Promise<string> {
        const path = this.getRelativeRepoPath(file, relativeToVault);

        return this.git.show([commitHash + ":" + path]);
    }

    private async getLocalBranchUpstream(
        localBranchName: string
    ): Promise<string | undefined> {
        // Returns the configured upstream ref for a local branch (e.g. `origin/main`), using
        // Return undefined when no upstream exists or if git throws an error.
        try {
            const upstream = await this.git.raw([
                "rev-parse",
                "--abbrev-ref",
                `${localBranchName}@{upstream}`,
            ]);
            const trimmed = upstream.trim();
            return trimmed.length > 0 ? trimmed : undefined;
        } catch {
            return undefined;
        }
    }

    private getAvailableLocalBranchName(
        remoteBranchName: string,
        remote: string,
        existingBranchNames: string[]
    ): string {
        // Chooses a local branch name that does not collide with `existingBranchNames`.
        // Prefers `remoteBranchName`, then `<remoteBranchName>-<remote>`, then that base with `-1`, `-2`, …
        //
        // Ex.: for a remote branch `origin/my-branch`
        // - `my-branch` is preferred
        // - `my-branch-origin` is next
        // - `my-branch-origin-1` is next
        // - `my-branch-origin-2` is next
        // - etc.

        const preferred = remoteBranchName;
        if (!existingBranchNames.includes(preferred)) {
            return preferred;
        }
        const base = `${remoteBranchName}-${remote}`;
        let candidate = base;
        let n = 0;
        while (existingBranchNames.includes(candidate)) {
            n += 1;
            candidate = `${base}-${n}`;
        }
        return candidate;
    }

    async checkout(branch: string, remote?: string): Promise<void> {
        return this.withGitOperation(GitOperation.checkout, async () => {
            if (remote) {
                // If we're trying to checkout a remote branch we'll either switch to an existing local branch that
                // already tracks it, or create a new local branch from the remote tip (name may be disambiguated).
                const remoteBranch = `${remote}/${branch}`;
                const branchInfo = await this.branchInfo();
                const localBranchExists = branchInfo.branches.includes(branch);

                // We found a local branch with the "correct" name, but it might track
                // a different remote, so we'll double check before proceeding.
                const existingBranchTracksRemote =
                    localBranchExists &&
                    (await this.getLocalBranchUpstream(branch)) ===
                        remoteBranch;

                if (existingBranchTracksRemote) {
                    // The local branch already exists AND it tracked the correct remote, so we can simply switch to it.
                    await this.git.checkout(branch);
                } else {
                    // The local branch doesn't exist or it tracks a different remote, so we'll need to create a new local branch.
                    // First we need to find a suitable name for the new local branch.
                    const localBranchName = this.getAvailableLocalBranchName(
                        branch,
                        remote,
                        branchInfo.branches
                    );

                    // Finally, we can use `git checkout -b` to create the new local branch and set it to track the remote branch.
                    await this.git.checkout([
                        "-b",
                        localBranchName,
                        remoteBranch,
                    ]);
                }
            } else {
                // Checkout an existing local branch (no remote specified).
                await this.git.checkout(branch);
            }

            if (this.plugin.settings.submoduleRecurseCheckout) {
                const submodulePaths = await this.getSubmodulePaths();
                for (const submodulePath of submodulePaths) {
                    const branchSummary = await this.git
                        .cwd({ path: submodulePath, root: false })
                        .branch();
                    if (Object.keys(branchSummary.branches).includes(branch)) {
                        await this.git
                            .cwd({ path: submodulePath, root: false })
                            .checkout(branch);
                    }
                }
            }
        });
    }

    async createBranch(branch: string): Promise<void> {
        await this.git.checkout(["-b", branch]);
    }

    async deleteBranch(branch: string, force: boolean): Promise<void> {
        await this.git.branch([force ? "-D" : "-d", branch]);
    }

    async branchIsMerged(branch: string): Promise<boolean> {
        const notMergedBranches = await this.git.branch(["--no-merged"]);
        return !notMergedBranches.all.contains(branch);
    }

    async init(): Promise<void> {
        await this.git.init(false);
    }

    async clone(url: string, dir: string, depth?: number): Promise<void> {
        await this.git.clone(
            url,
            path.join(
                (this.app.vault.adapter as FileSystemAdapter).getBasePath(),
                dir
            ),
            depth ? ["--depth", `${depth}`] : []
        );

        // Set required attributes like `absoluteRepoPath` and add the script to the exclude file if needed.
        await this.setGitInstance();
    }

    async setConfig(path: string, value: string | undefined): Promise<void> {
        if (value == undefined) {
            await this.git.raw(["config", "--local", "--unset", path]);
        } else {
            await this.git.addConfig(path, value);
        }
    }

    async getConfig(
        path: string,
        scope: "local" | "global" | "all" = "local"
    ): Promise<string | undefined> {
        const res = await this.git.getConfig(
            path.toLowerCase(),
            scope == "all" ? undefined : scope
        );
        return res.value ?? undefined;
    }

    async fetch(remote?: string): Promise<void> {
        return this.withGitOperation(GitOperation.fetch, async () => {
            await this.git.fetch(remote != undefined ? [remote] : []);
        });
    }

    async setRemote(name: string, url: string): Promise<void> {
        if ((await this.getRemotes()).includes(name))
            await this.git.remote(["set-url", name, url]);
        else {
            await this.git.remote(["add", name, url]);
        }
    }

    async getRemoteBranches(remote: string): Promise<string[]> {
        const res = await this.git.branch(["-r", "--list", `${remote}*`]);

        const list = [];
        for (const item in res.branches) {
            list.push(res.branches[item]!.name);
        }
        return list;
    }

    async getRemotes() {
        const res = await this.git.remote([]);
        if (res) {
            return res.trim().split("\n");
        } else {
            return [];
        }
    }

    async removeRemote(remoteName: string) {
        await this.git.removeRemote(remoteName);
    }

    /**
     * @param remoteBranch - The remote branch to set as upstream, in the format "remote/branch"
     */
    async updateUpstreamBranch(remoteBranch: string) {
        try {
            // git 1.8+
            await this.git.branch(["--set-upstream-to", remoteBranch]);
        } catch {
            try {
                // git 1.7 - 1.8
                await this.git.branch(["--set-upstream", remoteBranch]);
            } catch {
                // fallback for when setting upstream branch to a branch that does not exist on the remote yet. Setting it with push instead.
                const [remote, remoteBranchName] =
                    splitRemoteBranch(remoteBranch);
                const branchInfo = await this.branchInfo();
                await this.git.push([
                    "--set-upstream",
                    remote,
                    `${branchInfo.current}:${remoteBranchName}`,
                ]);
            }
        }
    }

    updateGitPath(_: string): Promise<void> {
        return this.setGitInstance();
    }

    updateBasePath(_: string): Promise<void> {
        return this.setGitInstance(true);
    }

    async getDiffString(
        filePath: string,
        stagedChanges = false,
        hash?: string
    ): Promise<string> {
        if (stagedChanges)
            return await this.git.diff(["--cached", "--", filePath]);
        if (hash) return await this.git.show([`${hash}`, "--", filePath]);
        else return await this.git.diff(["--", filePath]);
    }

    async diff(
        file: string,
        commit1: string,
        commit2: string
    ): Promise<string> {
        return await this.git.diff([`${commit1}..${commit2}`, "--", file]);
    }

    async rawCommand(command: string): Promise<string> {
        const parts = command.split(" "); // Very simple parsing, may need string-argv
        const firstPart = parts[0];
        if (firstPart === undefined) return "";
        const res = await this.git.raw(firstPart, ...parts.slice(1));
        return res;
    }

    async getSubmoduleOfFile(
        repositoryRelativeFile: string
    ): Promise<{ submodule: string; relativeFilepath: string } | undefined> {
        // Documentation: https://git-scm.com/docs/git-rev-parse

        if (
            !(await this.app.vault.adapter.exists(
                path.dirname(repositoryRelativeFile)
            ))
        ) {
            return undefined;
        }

        // git -C <dir-of-file> rev-parse --show-toplevel
        // returns the submodules repository root as an absolute path
        let submoduleRoot = await this.git.raw(
            [
                "-C",
                path.dirname(repositoryRelativeFile),
                "rev-parse",
                "--show-toplevel",
            ],
            (err) => err && console.warn("get-submodule-of-file", err?.message)
        );
        submoduleRoot = submoduleRoot.trim();

        // git -C <dir-of-file> rev-parse --show-superproject-working-tree
        // returns the parent git repository, if the file is in a submodule - otherwise empty.
        const superProject = await this.git.raw(
            [
                "-C",
                path.dirname(repositoryRelativeFile),
                "rev-parse",
                "--show-superproject-working-tree",
            ],
            (err) => err && console.warn("get-submodule-of-file", err?.message)
        );

        if (superProject.trim() === "") {
            return undefined; // not in submodule
        }

        const fsAdapter = this.app.vault.adapter as FileSystemAdapter;
        const absolutePath = fsAdapter.getFullPath(
            path.normalize(repositoryRelativeFile)
        );
        const newRelativePath = path.relative(submoduleRoot, absolutePath);

        return { submodule: submoduleRoot, relativeFilepath: newRelativePath };
    }

    async getLastCommitTime(): Promise<Date | undefined> {
        try {
            const res = await this.git.log({ n: 1 });
            if (res != null && res.latest != null) {
                return new Date(res.latest.date);
            }
        } catch (error) {
            if (error instanceof GitError) {
                if (error.message.contains("does not have any commits yet")) {
                    return undefined;
                }
            } else {
                throw error;
            }
        }
        return undefined;
    }

    private async isGitInstalled(): Promise<boolean> {
        // https://github.com/steveukx/git-js/issues/402
        const gitPath = this.plugin.localStorage.getGitPath();
        const command = await spawnAsync(gitPath || "git", ["--version"], {});

        if (command.error) {
            if (Platform.isWin && !gitPath) {
                this.plugin.log(
                    `Git not found in PATH. Checking standard installation path(${DEFAULT_WIN_GIT_PATH}) of Git for Windows.`
                );
                const command = await spawnAsync(DEFAULT_WIN_GIT_PATH, [
                    "--version",
                ]);
                if (command.error) {
                    console.error(command.error);
                    return false;
                } else {
                    this.useDefaultWindowsGitPath = true;
                }
            } else {
                console.error(command.error);
                return false;
            }
        } else {
            this.useDefaultWindowsGitPath = false;
        }
        return true;
    }

    private convertErrors(error: unknown): never {
        if (error instanceof GitError) {
            const message = String(error.message);
            const networkFailure =
                message.contains("Could not resolve host") ||
                message.contains("Unable to resolve host") ||
                message.contains("Unable to open connection") ||
                message.match(
                    /ssh: connect to host .*? port .*?: Operation timed out/
                ) != null ||
                message.match(
                    /ssh: connect to host .*? port .*?: Network is unreachable/
                ) != null ||
                message.match(
                    /ssh: connect to host .*? port .*?: Undefined error: 0/
                ) != null;
            if (networkFailure) {
                throw new NoNetworkError(message);
            }
        }
        throw error;
    }

    async isFileTrackedByLFS(filePath: string): Promise<boolean> {
        try {
            // Checks if Gits filter attribute is set to lfs for the file, which means it is (or will be) tracked by LFS.
            const result = await this.git.raw([
                "check-attr",
                "filter",
                filePath,
            ]);
            return result.includes("filter: lfs");
        } catch (error) {
            const errorMessage =
                error instanceof Error ? error.message : String(error);
            this.plugin.displayError(
                `Error checking LFS status: ${errorMessage}`
            );
            return false;
        }
    }
}

export const zeroCommit: BlameCommit = {
    hash: "000000",
    isZeroCommit: true,
    summary: "",
};

// Parse git blame porcelain format: https://git-scm.com/docs/git-blame#_the_porcelain_format
function parseBlame(blameOutputUnnormalized: string): Blame {
    const blameOutput = blameOutputUnnormalized.replace("\r\n", "\n");

    const blameLines = blameOutput.split("\n");

    const result: Blame = {
        commits: new Map(),
        hashPerLine: [undefined!], // one-based indices
        originalFileLineNrPerLine: [undefined!],
        finalFileLineNrPerLine: [undefined!],
        groupSizePerStartingLine: new Map(),
    };

    let line = 1;
    for (let bi = 0; bi < blameLines.length; ) {
        const blameLine = blameLines[bi];
        if (startsWithNonWhitespace(blameLine)) {
            const lineInfo = blameLine.split(" ");

            const commitHash = parseLineInfoInto(lineInfo, line, result);
            bi++;

            // parse header values until a tab is encountered
            for (; startsWithNonWhitespace(blameLines[bi]); bi++) {
                const spaceSeparatedHeaderValues = blameLines[bi]!.split(" ");
                parseHeaderInto(spaceSeparatedHeaderValues, result, line);
            }
            finalizeBlameCommitInfo(result.commits.get(commitHash)!);

            // skip tab prefixed line
            line += 1;
        } else if (blameLine === "" && bi === blameLines.length - 1) {
            // EOF
        } else {
            throw Error(
                `Expected non-whitespace line or EOF, but found: ${blameLine}`
            );
        }
        bi++;
    }
    return result;
}

function parseLineInfoInto(lineInfo: string[], line: number, result: Blame) {
    const hash = lineInfo[0];
    const originalLine = lineInfo[1];
    const finalLine = lineInfo[2];
    if (
        hash === undefined ||
        originalLine === undefined ||
        finalLine === undefined
    ) {
        throw Error(`Invalid git-blame line info: ${lineInfo.join(" ")}`);
    }
    result.hashPerLine.push(hash);
    result.originalFileLineNrPerLine.push(parseInt(originalLine));
    result.finalFileLineNrPerLine.push(parseInt(finalLine));
    if (lineInfo.length >= 4)
        result.groupSizePerStartingLine.set(line, parseInt(lineInfo[3]!));

    if (parseInt(finalLine) !== line) {
        throw Error(
            `git-blame output is out of order: ${line} vs ${finalLine}`
        );
    }

    return hash;
}

function parseHeaderInto(header: string[], out: Blame, line: number) {
    const key = header[0];
    const value = header.slice(1).join(" ");
    const commitHash = out.hashPerLine[line];
    if (commitHash === undefined) {
        throw Error(`No commit hash found for git-blame line ${line}`);
    }
    const commit =
        out.commits.get(commitHash) ||
        <BlameCommit>{
            hash: commitHash,
            author: {},
            committer: {},
            previous: {},
        };

    switch (key) {
        case "summary":
            commit.summary = value;
            break;

        case "author":
            commit.author!.name = value;
            break;
        case "author-mail":
            commit.author!.email = removeEmailBrackets(value);
            break;
        case "author-time":
            commit.author!.epochSeconds = parseInt(value);
            break;
        case "author-tz":
            commit.author!.tz = value;
            break;

        case "committer":
            commit.committer!.name = value;
            break;
        case "committer-mail":
            commit.committer!.email = removeEmailBrackets(value);
            break;
        case "committer-time":
            commit.committer!.epochSeconds = parseInt(value);
            break;
        case "committer-tz":
            commit.committer!.tz = value;
            break;

        case "previous":
            commit.previous!.commitHash = value;
            break;
        case "filename":
            commit.previous!.filename = value;
            break;
    }
    out.commits.set(commitHash, commit);
}

function finalizeBlameCommitInfo(commit: BlameCommit) {
    if (commit.summary === undefined) {
        throw Error(`Summary not provided for commit: ${commit.hash}`);
    }

    if (isUndefinedOrEmptyObject(commit.author)) {
        commit.author = undefined;
    }
    if (isUndefinedOrEmptyObject(commit.committer)) {
        commit.committer = undefined;
    }
    if (isUndefinedOrEmptyObject(commit.previous)) {
        commit.previous = undefined;
    }

    commit.isZeroCommit = Boolean(commit.hash.match(/^0*$/));
}

function isUndefinedOrEmptyObject(obj: object | undefined | null): boolean {
    return !obj || Object.keys(obj).length === 0;
}

function startsWithNonWhitespace(str: string | undefined): str is string {
    if (str === undefined) return false;
    return str.length > 0 && str[0]!.trim() === str[0];
}

function removeEmailBrackets(gitEmail: string) {
    const prefixCleaned = gitEmail.startsWith("<")
        ? gitEmail.substring(1)
        : gitEmail;
    return prefixCleaned.endsWith(">")
        ? prefixCleaned.substring(0, prefixCleaned.length - 1)
        : prefixCleaned;
}

function errorToString(error: unknown): string {
    return error instanceof Error ? error.message : String(error);
}
